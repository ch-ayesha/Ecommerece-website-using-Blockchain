import React from 'react'

export const NotFound = () => {
    return (
        <div className='container-fluid'>
            Error 404 Not found
        </div>
    )
}
